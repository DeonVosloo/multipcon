export default function Noop() {
  return null;
}
