export const LANGUAGES: string[];

export const LANGUAGES_SSR: string[];

export const LANGUAGES_IN_PROGRESS: string[];

export const LANGUAGES_IGNORE_PAGES: (pathname: string) => boolean;
