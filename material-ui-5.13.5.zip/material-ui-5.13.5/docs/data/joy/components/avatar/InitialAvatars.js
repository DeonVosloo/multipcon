import * as React from 'react';
import Avatar from '@mui/joy/Avatar';

export default function InitialAvatars() {
  return <Avatar>RE</Avatar>;
}
